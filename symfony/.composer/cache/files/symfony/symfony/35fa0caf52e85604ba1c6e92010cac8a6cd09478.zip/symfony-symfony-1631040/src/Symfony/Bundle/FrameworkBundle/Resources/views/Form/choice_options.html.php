<?php echo $view['form']->block($form, 'choice_widget_options') ?>
