<?php echo $view['form']->block($form, 'widget_container_attributes') ?>
