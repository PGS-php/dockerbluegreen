<?php

$container->loadFromExtension('framework', array(
    'templating' => false,
));
