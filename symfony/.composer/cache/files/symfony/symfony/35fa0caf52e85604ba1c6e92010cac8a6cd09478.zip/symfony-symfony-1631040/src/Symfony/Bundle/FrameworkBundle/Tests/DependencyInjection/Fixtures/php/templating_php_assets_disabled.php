<?php

$container->loadFromExtension('framework', array(
    'assets' => false,
    'templating' => array(
        'engines' => array('php'),
    ),
));
